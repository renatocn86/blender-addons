module = 0.2
pressureangle = 20.0